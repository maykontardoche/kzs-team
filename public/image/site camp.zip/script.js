/**************************************************
 *  EXEMPLO DE SCRIPT "TURBINADO" PARA O SITE
 *  - Navbar dinâmica ao rolar a página
 *  - Botão "Voltar ao Topo"
 *  - Animações de scroll
 *  - Exemplo de envio de formulário com alerta
 **************************************************/

document.addEventListener("DOMContentLoaded", () => {
  console.log("Site Warzone Championship carregado com sucesso!");

  // 1. Navbar dinâmica ao rolar a página
  const navbar = document.querySelector(".navbar");
  window.addEventListener("scroll", () => {
    if (window.scrollY > 50) {
      navbar.classList.add("scrolled");
    } else {
      navbar.classList.remove("scrolled");
    }
  });

  // 2. Botão de "Voltar ao Topo"
  const scrollTopBtn = document.createElement("button");
  scrollTopBtn.id = "scrollTopBtn";
  scrollTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
  document.body.appendChild(scrollTopBtn);

  // Mostrar/ocultar botão ao rolar
  window.addEventListener("scroll", () => {
    if (window.scrollY > 300) {
      scrollTopBtn.style.display = "block";
      scrollTopBtn.style.opacity = "1";
    } else {
      scrollTopBtn.style.display = "none";
      scrollTopBtn.style.opacity = "0";
    }
  });

  // Evento de clique para subir a página
  scrollTopBtn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  // 3. Animação de scroll suave em elementos .fade-in (caso queira)
  const animatedElements = document.querySelectorAll(".fade-in");

  const handleScrollAnimation = () => {
    animatedElements.forEach((el) => {
      const elementPos = el.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;
      // Ajuste o valor (windowHeight * 0.85) para quando a animação deve iniciar
      if (elementPos < windowHeight * 0.85) {
        el.classList.add("animated"); // classe "animated" dispara a animação (CSS)
      }
    });
  };

  // Chama no load e no scroll
  window.addEventListener("scroll", handleScrollAnimation);
  handleScrollAnimation(); // chama assim que carrega

  // 4. Exemplo de envio de formulário (Contato)
  const form = document.querySelector("form");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      // Pega valores
      const nome = document.querySelector("#nome")?.value || "";
      const email = document.querySelector("#email")?.value || "";
      const mensagem = document.querySelector("#mensagem")?.value || "";

      // Exemplo de validação rápida
      if (!nome || !email || !mensagem) {
        alert("Por favor, preencha todos os campos.");
        return;
      }

      // Exemplo de feedback
      alert(
        `Obrigado, ${nome}!\nRecebemos sua mensagem e entraremos em contato em breve.`
      );

      // Aqui você pode integrar com um backend ou serviço de e-mail
      // ...

      // Reset do formulário
      form.reset();
    });
  }
});
